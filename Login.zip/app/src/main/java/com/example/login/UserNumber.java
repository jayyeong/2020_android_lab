package com.example.login;

import android.app.Application;

public class UserNumber extends Application {
    //member variable
    private String userNumber;

    //member function
    public String getUserNumber() {
        return userNumber;
    }
    public void setUserNumber(String n) {
        userNumber = n;
    }
}
