package com.example.login;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class LoginActivity extends AppCompatActivity {

    private EditText _id,_pass;
    private Button btn_login,btn_register;
    String userID;
    String userPASS;

    private static String IP_ADDRESS = "192.168.43.32"; //ip 주소 (노트북이랑 핸드폰이 같은 와이파이면 그 와이파이 아이피주소로...)
    private static String TAG = "태그"; // 디버그 태그 이름

    private String mJsonString; // 서버에서 받아오는 json 값

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        _id=findViewById(R.id._id);
        _pass=findViewById(R.id._pass);
        btn_register=findViewById(R.id.btn_register);
        btn_login=findViewById(R.id.btn_login);

        //회원가입 버튼 클릭
        btn_register.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view){
                Intent intent = new Intent(getApplicationContext(), RegisterActivity.class);
                startActivity(intent);
            }
        });

        //로그인 버튼 클릭
        btn_login.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view){
                userID = _id.getText().toString();
                userPASS = _pass.getText().toString();

                GetData task = new GetData();
                task.execute( "http://" + IP_ADDRESS + "/getjson.php", "");
            }
        });
    }

    //AsyncTask 작동
    private class GetData extends AsyncTask<String, Void, String> {

        ProgressDialog progressDialog;
        String errorString = null;

        // 실행하기 전
        @Override
        protected void onPreExecute() {
            super.onPreExecute();

            progressDialog = ProgressDialog.show(LoginActivity.this,
                    "Please Wait", null, true, true);
        }

        // 값이 왔다고 전달받으면
       @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);

            progressDialog.dismiss();
            Log.d(TAG, "response - " + result);

            if (result == null){

                Log.d(TAG, "Error:" + result);
            }
            else {
                //결과값을 받아온 후,
                mJsonString = result;
                //값을 처리한다.
                showResult();
            }
        }

        //백 그라운드
        @Override
        protected String doInBackground(String... params) {

            String serverURL = params[0];
            String postParameters = params[1];


            try {

                URL url = new URL(serverURL);
                HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();


                httpURLConnection.setReadTimeout(5000);
                httpURLConnection.setConnectTimeout(5000);
                httpURLConnection.setRequestMethod("POST");
                httpURLConnection.setDoInput(true);
                httpURLConnection.connect();


                OutputStream outputStream = httpURLConnection.getOutputStream();
                outputStream.write(postParameters.getBytes("UTF-8"));
                outputStream.flush();
                outputStream.close();


                int responseStatusCode = httpURLConnection.getResponseCode();
                Log.d(TAG, "response code - " + responseStatusCode);

                InputStream inputStream;
                if(responseStatusCode == HttpURLConnection.HTTP_OK) {
                    inputStream = httpURLConnection.getInputStream();
                }
                else{
                    inputStream = httpURLConnection.getErrorStream();
                }


                InputStreamReader inputStreamReader = new InputStreamReader(inputStream, "UTF-8");
                BufferedReader bufferedReader = new BufferedReader(inputStreamReader);

                StringBuilder sb = new StringBuilder();
                String line;

                while((line = bufferedReader.readLine()) != null){
                    sb.append(line);
                }

                bufferedReader.close();

                return sb.toString().trim();


            } catch (Exception e) {

                Log.d(TAG, "GetData : Error ", e);
                errorString = e.toString();

                return null;
            }

        }
    }


    private void showResult(){

        String TAG_JSON="webnautes";
        String TAG_ID = "id";
        String TAG_NUM = "num";
        String TAG_PASSWORD ="password";


        try {
            JSONObject jsonObject = new JSONObject(mJsonString);
            JSONArray jsonArray = jsonObject.getJSONArray(TAG_JSON);

            int i;
            for(i = 0; i < jsonArray.length(); i++)
            {
                JSONObject item = jsonArray.getJSONObject(i);

                String id = item.getString(TAG_ID);
                String num = item.getString(TAG_NUM);
                String password = item.getString(TAG_PASSWORD);

                if (id.equals(userID)){
                    if (password.equals(userPASS)){
                        Log.d(TAG, "일치하는 회원정보 발견");

                        UserNumber user = (UserNumber) getApplication();
                        user.setUserNumber(num);

                        Intent intent = new Intent(getApplicationContext(), ChooseActivity.class);
                        startActivity(intent);
                        break;
                    }
                }
            }
            //일치하는 회원정보를 발견하지 못한 경우
            if (i == jsonArray.length())
                Toast.makeText(this.getApplicationContext(),"아이디나 비밀번호가 맞지 않습니다.",Toast.LENGTH_SHORT).show();

            //로그인 입력칸 비우기
            userID = "";
            userPASS = "";

        } catch (JSONException e) {

            Log.d(TAG, "showResult : ", e);
        }

    }
}
