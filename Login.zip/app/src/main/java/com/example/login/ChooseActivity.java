package com.example.login;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class ChooseActivity extends AppCompatActivity {

    private Button btn_like,btn_hate,btn_soso;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_choose);

        btn_like = findViewById(R.id.btn_like);
        btn_hate = findViewById(R.id.btn_hate);
        btn_soso = findViewById(R.id.btn_soso);

        UserNumber user = (UserNumber) getApplication();
        String userNumber = user.getUserNumber();
        Toast.makeText(this.getApplicationContext(),userNumber,Toast.LENGTH_SHORT).show();

        btn_like.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Intent intent = new Intent(ChooseActivity.this, MapActivity.class);
                startActivity(intent);
            }
        });
/*
        btn_hate.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });

        btn_hate.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });
         */
    }
}
